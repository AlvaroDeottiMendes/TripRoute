using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TravelRoutesAPI.Data;
using TravelRoutesAPI.Models;

namespace TravelRoutesAPI.Repositories
{
    public class RouteRepository : IRouteRepository
    {
        private readonly ApplicationDbContext _context;

        public RouteRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Route>> GetAllRoutesAsync()
        {
            return await _context.Routes.ToListAsync();
        }

        public async Task<Route> GetRouteByIdAsync(int id)
        {
            return await _context.Routes.FindAsync(id);
        }

        public async Task AddRouteAsync(Route route)
        {
            await _context.Routes.AddAsync(route);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateRouteAsync(Route route)
        {
            _context.Routes.Update(route);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteRouteAsync(int id)
        {
            var route = await _context.Routes.FindAsync(id);
            if (route != null)
            {
                _context.Routes.Remove(route);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Route>> FindRoutesAsync(string origin, string destination)
        {
            // Lógica para encontrar as melhores rotas
            var routes = await _context.Routes.ToListAsync();
            // Implementar algoritmo para encontrar a rota mais barata
            return routes.Where(r => r.Origin == origin && r.Destination == destination);
        }
    }
}

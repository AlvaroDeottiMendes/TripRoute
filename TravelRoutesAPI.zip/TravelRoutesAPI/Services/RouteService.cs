using System.Collections.Generic;
using System.Threading.Tasks;
using TravelRoutesAPI.Models;
using TravelRoutesAPI.Repositories;

namespace TravelRoutesAPI.Services
{
    public class RouteService : IRouteService
    {
        private readonly IRouteRepository _routeRepository;

        public RouteService(IRouteRepository routeRepository)
        {
            _routeRepository = routeRepository;
        }

        public async Task<IEnumerable<Route>> GetAllRoutesAsync()
        {
            return await _routeRepository.GetAllRoutesAsync();
        }

        public async Task<Route> GetRouteByIdAsync(int id)
        {
            return await _routeRepository.GetRouteByIdAsync(id);
        }

        public async Task AddRouteAsync(Route route)
        {
            await _routeRepository.AddRouteAsync(route);
        }

        public async Task UpdateRouteAsync(Route route)
        {
            await _routeRepository.UpdateRouteAsync(route);
        }

        public async Task DeleteRouteAsync(int id)
        {
            await _routeRepository.DeleteRouteAsync(id);
        }

        public async Task<IEnumerable<Route>> FindRoutesAsync(string origin, string destination)
        {
            return await _routeRepository.FindRoutesAsync(origin, destination);
        }
    }
}

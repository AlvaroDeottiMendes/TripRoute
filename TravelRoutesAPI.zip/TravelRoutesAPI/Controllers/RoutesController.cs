using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TravelRoutesAPI.Models;
using TravelRoutesAPI.Services;

namespace TravelRoutesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoutesController : ControllerBase
    {
        private readonly IRouteService _routeService;

        public RoutesController(IRouteService routeService)
        {
            _routeService = routeService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Route>>> GetRoutes()
        {
            var routes = await _routeService.GetAllRoutesAsync();
            return Ok(routes);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Route>> GetRoute(int id)
        {
            var route = await _routeService.GetRouteByIdAsync(id);
            if (route == null)
            {
                return NotFound();
            }
            return Ok(route);
        }

        [HttpPost]
        public async Task<ActionResult<Route>> AddRoute(Route route)
        {
            await _routeService.AddRouteAsync(route);
            return CreatedAtAction(nameof(GetRoute), new { id = route.Id }, route);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRoute(int id, Route route)
        {
            if (id != route.Id)
            {
                return BadRequest();
            }

            await _routeService.UpdateRouteAsync(route);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoute(int id)
        {
            await _routeService.DeleteRouteAsync(id);
            return NoContent();
        }

        [HttpGet("find")]
        public async Task<ActionResult<IEnumerable<Route>>> FindRoutes([FromQuery] string origin, [FromQuery] string destination)
        {
            var routes = await _routeService.FindRoutesAsync(origin, destination);
            return Ok(routes);
        }
    }
}

using System.Collections.Generic;
using System.Threading.Tasks;
using TravelRoutesAPI.Models;

namespace TravelRoutesAPI.Repositories
{
    public interface IRouteRepository
    {
        Task<IEnumerable<Route>> GetAllRoutesAsync();
        Task<Route> GetRouteByIdAsync(int id);
        Task AddRouteAsync(Route route);
        Task UpdateRouteAsync(Route route);
        Task DeleteRouteAsync(int id);
        Task<IEnumerable<Route>> FindRoutesAsync(string origin, string destination);
    }
}
